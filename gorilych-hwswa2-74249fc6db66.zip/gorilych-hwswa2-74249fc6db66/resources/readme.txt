This directory contain external resources, like wagent.exe.
